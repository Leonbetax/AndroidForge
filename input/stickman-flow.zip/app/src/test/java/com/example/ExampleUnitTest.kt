package com.example

import com.example.domain.BatchPromptParser
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testBatchPromptParser_splitsByBlankLines() {
        val input = """
            Escena 1: Un stickman mira por la ventana.

            Escena 2: Un jardín sin abejas con flores marchitas.

            Escena 3: Las plantas pierden sus hojas.
        """.trimIndent()

        val parsed = BatchPromptParser.parseBatchText(input)
        assertEquals(3, parsed.size)
        assertEquals(1, parsed[0].orderIndex)
        assertEquals("Escena 1", parsed[0].title)
        assertEquals("Un stickman mira por la ventana.", parsed[0].prompt)

        assertEquals(2, parsed[1].orderIndex)
        assertEquals("Escena 2", parsed[1].title)
        assertEquals("Un jardín sin abejas con flores marchitas.", parsed[1].prompt)
    }

    @Test
    fun testBatchPromptParser_buildCombinedPrompt() {
        val style = "Animación 2D de stickman, personajes de líneas negras sencillas"
        val prompt = "Un stickman corriendo en el parque"
        val combined = BatchPromptParser.buildCombinedPrompt(prompt, style, hasReferenceImage = false)

        assertTrue(combined.contains(style))
        assertTrue(combined.contains(prompt))
    }
}
