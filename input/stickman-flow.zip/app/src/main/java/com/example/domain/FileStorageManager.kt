package com.example.domain

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class FileStorageManager(private val context: Context) {

    fun getProjectDirectory(projectName: String): File {
        val sanitized = sanitizeFileName(projectName)
        val baseDir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir,
            "StickmanFlow/$sanitized"
        )
        if (!baseDir.exists()) {
            baseDir.mkdirs()
        }
        return baseDir
    }

    fun saveBase64Image(
        projectName: String,
        orderIndex: Int,
        sceneTitle: String,
        base64Data: String
    ): File {
        val projectDir = getProjectDirectory(projectName)
        val paddedIndex = String.format("%03d", orderIndex)
        val sanitizedTitle = sanitizeFileName(sceneTitle).ifBlank { "Escena" }
        val fileName = "${paddedIndex}_${sanitizedTitle}.png"
        val targetFile = File(projectDir, fileName)

        val imageBytes = Base64.decode(base64Data, Base64.DEFAULT)
        FileOutputStream(targetFile).use { output ->
            output.write(imageBytes)
            output.flush()
        }

        // Notify media scanner
        try {
            MediaScannerConnection.scanFile(
                context,
                arrayOf(targetFile.absolutePath),
                arrayOf("image/png"),
                null
            )
        } catch (_: Exception) {}

        return targetFile
    }

    fun getFileUri(file: File): Uri {
        return try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            Uri.fromFile(file)
        }
    }

    fun createShareIntent(files: List<File>, projectTitle: String): Intent {
        val uris = ArrayList<Uri>()
        for (f in files) {
            if (f.exists()) {
                uris.add(getFileUri(f))
            }
        }
        return if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uris.first())
                putExtra(Intent.EXTRA_SUBJECT, projectTitle)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_SUBJECT, projectTitle)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .replace(Regex("_+"), "_")
            .trim('_')
            .take(40)
    }
}
