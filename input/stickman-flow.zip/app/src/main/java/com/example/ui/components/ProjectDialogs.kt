package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SceneEntity
import com.example.domain.BatchPromptParser

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, script: String) -> Unit
) {
    var projectName by remember { mutableStateOf("") }
    var useSampleScript by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Crear Nuevo Proyecto",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Nombre del Proyecto / Episodio:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    placeholder = { Text("Ej: Episodio 2: La Ciudad Stickman") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_name_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Cargar guion de ejemplo para empezar",
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = useSampleScript,
                        onCheckedChange = { useSampleScript = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val script = if (useSampleScript) BatchPromptParser.SAMPLE_BATCH_SCRIPT else ""
                    onConfirm(projectName, script)
                },
                enabled = projectName.isNotBlank(),
                modifier = Modifier.testTag("confirm_create_project_button")
            ) {
                Text("Crear Proyecto")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun EditSceneDialog(
    scene: SceneEntity,
    onDismiss: () -> Unit,
    onConfirm: (newPrompt: String) -> Unit
) {
    var prompt by remember(scene) { mutableStateOf(scene.promptContent) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Editar ${scene.sceneTitle}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Ajusta la descripción de esta escena:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .testTag("edit_scene_prompt_input"),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(prompt) },
                enabled = prompt.isNotBlank(),
                modifier = Modifier.testTag("save_edit_scene_button")
            ) {
                Text("Guardar Cambios")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
