package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ImagenPrediction(
    @Json(name = "bytesBase64Encoded") val bytesBase64Encoded: String? = null,
    @Json(name = "mimeType") val mimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class ImagenResponse(
    @Json(name = "predictions") val predictions: List<ImagenPrediction>? = null
)

@JsonClass(generateAdapter = true)
data class ImagenInstance(
    @Json(name = "prompt") val prompt: String
)

@JsonClass(generateAdapter = true)
data class ImagenOutputOptions(
    @Json(name = "mimeType") val mimeType: String = "image/png"
)

@JsonClass(generateAdapter = true)
data class ImagenParameters(
    @Json(name = "sampleCount") val sampleCount: Int = 1,
    @Json(name = "aspectRatio") val aspectRatio: String = "16:9",
    @Json(name = "outputOptions") val outputOptions: ImagenOutputOptions = ImagenOutputOptions()
)

@JsonClass(generateAdapter = true)
data class ImagenRequest(
    @Json(name = "instances") val instances: List<ImagenInstance>,
    @Json(name = "parameters") val parameters: ImagenParameters = ImagenParameters()
)
