package com.example.domain

import com.example.data.local.SceneEntity

data class ParsedSceneItem(
    val orderIndex: Int,
    val title: String,
    val prompt: String
)

object BatchPromptParser {

    const val DEFAULT_STICKMAN_STYLE =
        "Animación 2D de stickman, personajes de líneas negras sencillas, fondo blanco o minimalista, composición clara, estilo consistente, sin texto en pantalla, encuadre cinematográfico 16:9"

    /**
     * Splits raw text by one or more blank lines (\n\s*\n).
     * Parses each chunk, extracting any "Escena X:" or "Scene X:" label if present,
     * or assigns orderIndex sequentially.
     */
    fun parseBatchText(rawText: String): List<ParsedSceneItem> {
        if (rawText.isBlank()) return emptyList()

        // Normalize line breaks
        val normalized = rawText.replace("\r\n", "\n").replace("\r", "\n")
        
        // Split on two or more newlines (with optional whitespace in between)
        val chunks = normalized.split(Regex("\n\\s*\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        return chunks.mapIndexed { index, chunk ->
            val order = index + 1
            // Check for prefix like "Escena 1:", "Escena 01 -", "Scene 1:", "1.", "1 -", etc.
            val prefixRegex = Regex("^(?:(?:Escena|Scene)\\s*\\d+|\\d+)[\\s:.-]+(.*)$", RegexOption.IGNORE_CASE)
            val match = prefixRegex.find(chunk)

            val (title, content) = if (match != null) {
                val extractedContent = match.groupValues[1].trim()
                Pair("Escena $order", if (extractedContent.isNotBlank()) extractedContent else chunk)
            } else {
                Pair("Escena $order", chunk)
            }

            ParsedSceneItem(
                orderIndex = order,
                title = title,
                prompt = content
            )
        }
    }

    /**
     * Builds the final prompt combining the visual style, reference instructions, and scene action.
     */
    fun buildCombinedPrompt(
        scenePrompt: String,
        visualStyle: String,
        hasReferenceImage: Boolean = false,
        isGoogleFlowMode: Boolean = false
    ): String {
        val cleanStyle = visualStyle.trim().trimEnd('.')
        val cleanScene = scenePrompt.trim().trimEnd('.')

        return buildString {
            append(cleanStyle)
            append(". ")
            if (hasReferenceImage) {
                append("Mantén estricta consistencia visual de personaje y proporciones con la imagen de referencia. ")
            }
            if (isGoogleFlowMode) {
                append("[Google Flow Prompt]: ")
            }
            append(cleanScene)
            append(".")
        }
    }

    /**
     * Exports scenes back to formatted batch text.
     */
    fun formatScenesToBatchText(scenes: List<SceneEntity>): String {
        return scenes.sortedBy { it.orderIndex }.joinToString(separator = "\n\n") { scene ->
            "${scene.sceneTitle}: ${scene.promptContent}"
        }
    }

    /**
     * Sample script provided in the prompt requirements for easy 1-click loading.
     */
    val SAMPLE_BATCH_SCRIPT = """
Escena 1: Un stickman mira por la ventana de su habitación y descubre asombrado que no hay ninguna abeja en el jardín.

Escena 2: Un jardín silencioso sin abejas, con flores solitarias y árboles estáticos bajo el cielo despejado.

Escena 3: Las plantas comienzan a perder sus pétalos y las flores se marchitan lentamente por falta de polinización.

Escena 4: El stickman sale al exterior con una libreta y una lupa, buscando rastros e investigando el suelo.

Escena 5: El stickman descubre una pequeña colmena vacía en una rama de árbol y comprende la gravedad de la situación.

Escena 6: El stickman dibuja un plano en una pizarra con ideas para crear flores artificiales y proteger el ecosistema.
    """.trimIndent()
}
