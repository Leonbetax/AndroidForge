package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.BatchPromptParser
import com.example.ui.MainViewModel

@Composable
fun VisualStyleScreen(viewModel: MainViewModel) {
    val visualStyle by viewModel.visualStyleText.collectAsState()
    val referenceImageUri by viewModel.referenceImageUri.collectAsState()
    val generationMode by viewModel.generationMode.collectAsState()
    val engineMode by viewModel.engineMode.collectAsState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri: Uri? ->
            viewModel.setReferenceImageUri(uri?.toString())
        }
    )

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Header
        Column {
            Text(
                text = "Estilo Visual & Referencia",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Define la coherencia estética para todas las escenas del lote",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Mode Selector: Imágenes vs Vídeos
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Tipo de Contenido a Generar",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = generationMode == "IMAGES",
                        onClick = { viewModel.setGenerationMode("IMAGES") },
                        label = { Text("🖼️ Imágenes 16:9 (HD)") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = generationMode == "VIDEOS",
                        onClick = { viewModel.setGenerationMode("VIDEOS") },
                        label = { Text("🎥 Vídeos (Flow / Veo)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (generationMode == "VIDEOS") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Modo Vídeo: Optimiza los prompts para clips cinematográficos y transiciones de cámara para YouTube Shorts o vídeos largos.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Visual Style Field
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Descripción de Estilo Stickman Común",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    TextButton(
                        onClick = { viewModel.updateVisualStyle(BatchPromptParser.DEFAULT_STICKMAN_STYLE) }
                    ) {
                        Text("Restablecer", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = visualStyle,
                    onValueChange = { viewModel.updateVisualStyle(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("visual_style_input"),
                    shape = RoundedCornerShape(12.dp),
                    placeholder = { Text("Describe el estilo visual stickman...") }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Presets
                Text(
                    text = "Estilos Predefinidos:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PresetChip(
                        title = "2D Minimal",
                        onClick = {
                            viewModel.updateVisualStyle(
                                "Animación 2D de stickman, personajes de líneas negras sencillas, fondo blanco o minimalista, composición clara, estilo consistente, sin texto en pantalla, encuadre cinematográfico 16:9"
                            )
                        }
                    )
                    PresetChip(
                        title = "Pizarra Negra",
                        onClick = {
                            viewModel.updateVisualStyle(
                                "Estilo stickman de tiza blanca sobre fondo de pizarra oscura mate, estilo animado explicativo, líneas expresivas nítidas, encuadre 16:9"
                            )
                        }
                    )
                    PresetChip(
                        title = "Detalles Color",
                        onClick = {
                            viewModel.updateVisualStyle(
                                "Animación stickman con líneas negras gruesas y acentos de color vibrante en objetos clave, sombras planas, fondo limpio, encuadre 16:9"
                            )
                        }
                    )
                }
            }
        }

        // Reference Image Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Imagen de Referencia Visual Común",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Selecciona una imagen de tu galería para mantener la consistencia del personaje o del entorno a lo largo de todas las escenas.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (referenceImageUri != null) {
                    // Preview of selected image
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = referenceImageUri,
                            contentDescription = "Imagen de referencia seleccionada",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cambiar Foto")
                        }

                        Button(
                            onClick = { viewModel.setReferenceImageUri(null) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Quitar")
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Referencia visual activa: Se enviará en cada prompt para condicionar el estilo.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                } else {
                    // Empty state: Select from gallery
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("select_reference_image_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Seleccionar Imagen de Galería")
                    }
                }
            }
        }
    }
}

@Composable
fun PresetChip(title: String, onClick: () -> Unit) {
    SuggestionChip(
        onClick = onClick,
        label = { Text(title, fontSize = 11.sp) },
        shape = RoundedCornerShape(8.dp)
    )
}
