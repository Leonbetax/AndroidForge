package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.ProjectDao
import com.example.data.local.ProjectEntity
import com.example.data.local.SceneDao
import com.example.data.local.SceneEntity
import com.example.data.remote.GoogleImagenApiService
import com.example.data.remote.ImagenInstance
import com.example.data.remote.ImagenOutputOptions
import com.example.data.remote.ImagenParameters
import com.example.data.remote.ImagenRequest
import com.example.domain.FileStorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

class GenerationRepository(
    private val context: Context,
    private val projectDao: ProjectDao,
    private val sceneDao: SceneDao,
    private val fileStorageManager: FileStorageManager,
    private val apiService: GoogleImagenApiService = GoogleImagenApiService.create()
) {
    private val sharedPrefs = context.getSharedPreferences("stickman_flow_prefs", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        val customKey = sharedPrefs.getString("custom_api_key", "") ?: ""
        if (customKey.isNotBlank()) return customKey.trim()

        // Fallback to BuildConfig if provided
        return try {
            val buildKey = BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
            buildKey?.trim() ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    fun saveApiKey(key: String) {
        sharedPrefs.edit().putString("custom_api_key", key.trim()).apply()
    }

    fun getAllProjects(): Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun getLatestProject(): Flow<ProjectEntity?> = projectDao.getLatestProject()

    suspend fun getProjectById(id: Long): ProjectEntity? = projectDao.getProjectById(id)

    suspend fun saveProject(project: ProjectEntity): Long = projectDao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)

    suspend fun deleteProject(projectId: Long) {
        projectDao.deleteProjectById(projectId)
    }

    fun getScenesForProject(projectId: Long): Flow<List<SceneEntity>> = sceneDao.getScenesForProject(projectId)

    fun getCompletedScenes(projectId: Long): Flow<List<SceneEntity>> = sceneDao.getCompletedScenes(projectId)

    suspend fun getScenesList(projectId: Long): List<SceneEntity> = sceneDao.getScenesListForProject(projectId)

    suspend fun insertScenes(scenes: List<SceneEntity>) = sceneDao.insertScenes(scenes)

    suspend fun insertScene(scene: SceneEntity): Long = sceneDao.insertScene(scene)

    suspend fun updateScene(scene: SceneEntity) = sceneDao.updateScene(scene)

    suspend fun updateScenes(scenes: List<SceneEntity>) = sceneDao.updateScenes(scenes)

    suspend fun deleteScene(scene: SceneEntity) = sceneDao.deleteScene(scene)

    suspend fun deleteSceneById(id: Long) = sceneDao.deleteSceneById(id)

    suspend fun deleteAllScenes(projectId: Long) = sceneDao.deleteAllScenesForProject(projectId)

    suspend fun resetFailedScenes(projectId: Long) = sceneDao.resetFailedScenes(projectId)

    suspend fun updateSceneProgress(id: Long, status: String, progress: Int, error: String? = null) {
        sceneDao.updateSceneProgress(id, status, progress, error)
    }

    /**
     * Executes real generation for a scene.
     */
    suspend fun generateSceneContent(
        project: ProjectEntity,
        scene: SceneEntity,
        onProgress: (Int, String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            onProgress(15, "Preparando prompt con estilo stickman...")
            val apiKey = getApiKey()

            if (apiKey.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Clave de API de Google no configurada. Ingresa tu API Key en la pestaña de Ajustes para generar contenido real.")
                )
            }

            onProgress(35, "Conectando con Google AI (Imagen 3)...")

            val request = ImagenRequest(
                instances = listOf(ImagenInstance(prompt = scene.fullCombinedPrompt)),
                parameters = ImagenParameters(
                    sampleCount = 1,
                    aspectRatio = "16:9",
                    outputOptions = ImagenOutputOptions(mimeType = "image/png")
                )
            )

            val response = apiService.generateImage(apiKey = apiKey, request = request)

            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string().orEmpty()
                val code = response.code()
                val errorMsg = when (code) {
                    400 -> "Petición no válida (400): $errorBody"
                    401, 403 -> "Error de autorización (403): La clave de API de Google es inválida o no tiene permisos para Imagen 3."
                    429 -> "Límite de cuota excedido (429): Google AI ha restringido temporalmente las peticiones. Espera un momento y reintenta."
                    500, 503 -> "Servidor de Google AI no disponible temporalmente ($code). Reintenta en unos instantes."
                    else -> "Error HTTP $code: $errorBody"
                }
                return@withContext Result.failure(Exception(errorMsg))
            }

            onProgress(75, "Procesando respuesta y decodificando imagen...")
            val predictions = response.body()?.predictions
            val base64Data = predictions?.firstOrNull()?.bytesBase64Encoded

            if (base64Data.isNullOrBlank()) {
                return@withContext Result.failure(
                    Exception("La respuesta de Google no incluyó bytes de imagen válidos.")
                )
            }

            onProgress(90, "Guardando archivo en almacenamiento local...")
            val savedFile = fileStorageManager.saveBase64Image(
                projectName = project.name,
                orderIndex = scene.orderIndex,
                sceneTitle = scene.sceneTitle,
                base64Data = base64Data
            )

            val fileUri = fileStorageManager.getFileUri(savedFile)
            val updatedScene = scene.copy(
                status = "COMPLETED",
                progressPercent = 100,
                localFilePath = savedFile.absolutePath,
                fileUri = fileUri.toString(),
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
            sceneDao.updateScene(updatedScene)

            onProgress(100, "¡Escena completada exitosamente!")
            Result.success(savedFile)
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: "Error inesperado durante la generación"
            sceneDao.updateSceneProgress(scene.id, "FAILED", 0, errorMsg)
            Result.failure(e)
        }
    }

    /**
     * Generates a local offline stickman storyboard sketch when testing or offline.
     * This provides a real functional render on the device without calling external APIs.
     */
    suspend fun generateLocalStoryboardSketch(
        project: ProjectEntity,
        scene: SceneEntity
    ): File = withContext(Dispatchers.IO) {
        val width = 1280
        val height = 720
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        canvas.drawColor(Color.WHITE)

        val strokePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 8f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        val fillPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 34f
            isAntiAlias = true
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 48f
            isFakeBoldText = true
            isAntiAlias = true
        }

        // Draw ground line
        canvas.drawLine(100f, 540f, 1180f, 540f, strokePaint)

        // Draw Stickman figure based on scene index for variety
        val centerX = 640f
        val centerY = 360f

        // Head
        canvas.drawCircle(centerX, centerY - 80f, 45f, strokePaint)

        // Torso
        canvas.drawLine(centerX, centerY - 35f, centerX, centerY + 100f, strokePaint)

        // Arms based on scene order
        when (scene.orderIndex % 3) {
            0 -> {
                // Pointing/Looking
                canvas.drawLine(centerX, centerY, centerX - 70f, centerY + 40f, strokePaint)
                canvas.drawLine(centerX, centerY, centerX + 90f, centerY - 50f, strokePaint)
            }
            1 -> {
                // Investigating / Hands on hips
                canvas.drawLine(centerX, centerY, centerX - 60f, centerY + 50f, strokePaint)
                canvas.drawLine(centerX, centerY, centerX + 60f, centerY + 50f, strokePaint)
            }
            else -> {
                // Running / Walking
                canvas.drawLine(centerX, centerY, centerX - 80f, centerY + 20f, strokePaint)
                canvas.drawLine(centerX, centerY, centerX + 80f, centerY + 20f, strokePaint)
            }
        }

        // Legs
        canvas.drawLine(centerX, centerY + 100f, centerX - 60f, 540f, strokePaint)
        canvas.drawLine(centerX, centerY + 100f, centerX + 60f, 540f, strokePaint)

        // Title and description overlay
        canvas.drawText("${project.name} • ${scene.sceneTitle}", 100f, 80f, titlePaint)
        
        // Wrap prompt text if long
        val promptWords = scene.promptContent.split(" ")
        var line = ""
        var lineY = 610f
        for (word in promptWords) {
            if (line.length + word.length > 55) {
                canvas.drawText(line, 100f, lineY, textPaint)
                line = "$word "
                lineY += 42f
            } else {
                line += "$word "
            }
        }
        if (line.isNotBlank()) {
            canvas.drawText(line, 100f, lineY, textPaint)
        }

        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        val base64Data = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

        val savedFile = fileStorageManager.saveBase64Image(
            projectName = project.name,
            orderIndex = scene.orderIndex,
            sceneTitle = scene.sceneTitle,
            base64Data = base64Data
        )

        val fileUri = fileStorageManager.getFileUri(savedFile)
        val updatedScene = scene.copy(
            status = "COMPLETED",
            progressPercent = 100,
            localFilePath = savedFile.absolutePath,
            fileUri = fileUri.toString(),
            errorMessage = null,
            updatedAt = System.currentTimeMillis()
        )
        sceneDao.updateScene(updatedScene)
        savedFile
    }

    fun getProjectDirectory(projectName: String): File = fileStorageManager.getProjectDirectory(projectName)

    fun createShareIntent(files: List<File>, projectTitle: String) =
        fileStorageManager.createShareIntent(files, projectTitle)
}
