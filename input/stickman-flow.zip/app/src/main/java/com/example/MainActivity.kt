package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.MainViewModel
import com.example.ui.components.EditSceneDialog
import com.example.ui.components.NewProjectDialog
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val sceneToEdit by viewModel.sceneToEdit.collectAsState()
    val showNewProjectDialog by viewModel.showNewProjectDialog.collectAsState()
    val showSettingsDialog by viewModel.showSettingsDialog.collectAsState()

    // Handle back button on secondary tabs
    if (currentTab != 0) {
        BackHandler {
            viewModel.setTab(0)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_navigation_bar"),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { viewModel.setTab(0) },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Panel") },
                    label = { Text("Panel") },
                    modifier = Modifier.testTag("nav_dashboard")
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { viewModel.setTab(1) },
                    icon = { Icon(Icons.Default.EditNote, contentDescription = "Editor") },
                    label = { Text("Editor") },
                    modifier = Modifier.testTag("nav_editor")
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { viewModel.setTab(2) },
                    icon = { Icon(Icons.Default.Palette, contentDescription = "Estilo") },
                    label = { Text("Estilo") },
                    modifier = Modifier.testTag("nav_style")
                )
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { viewModel.setTab(3) },
                    icon = { Icon(Icons.Default.QueueMusic, contentDescription = "Cola") },
                    label = { Text("Cola") },
                    modifier = Modifier.testTag("nav_queue")
                )
                NavigationBarItem(
                    selected = currentTab == 4,
                    onClick = { viewModel.setTab(4) },
                    icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = "Galería") },
                    label = { Text("Galería") },
                    modifier = Modifier.testTag("nav_gallery")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> DashboardScreen(viewModel = viewModel)
                1 -> BatchEditorScreen(viewModel = viewModel)
                2 -> VisualStyleScreen(viewModel = viewModel)
                3 -> QueueScreen(viewModel = viewModel)
                4 -> GalleryScreen(viewModel = viewModel)
            }
        }
    }

    // Modal Dialogs
    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { viewModel.setShowNewProjectDialog(false) },
            onConfirm = { name, script ->
                viewModel.createNewProject(name, script)
            }
        )
    }

    if (showSettingsDialog) {
        SettingsScreen(
            viewModel = viewModel,
            onDismiss = { viewModel.setShowSettingsDialog(false) }
        )
    }

    if (sceneToEdit != null) {
        EditSceneDialog(
            scene = sceneToEdit!!,
            onDismiss = { viewModel.setEditingScene(null) },
            onConfirm = { newPrompt ->
                viewModel.updateSingleScenePrompt(sceneToEdit!!.id, newPrompt)
            }
        )
    }
}
