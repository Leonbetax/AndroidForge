package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val visualStyle: String,
    val referenceImageUri: String? = null,
    val generationMode: String = "IMAGES", // "IMAGES" or "VIDEOS"
    val engineMode: String = "IMAGEN_API", // "IMAGEN_API" or "FLOW_ASSISTANT"
    val rawBatchText: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
