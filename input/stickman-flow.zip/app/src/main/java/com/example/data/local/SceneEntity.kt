package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "scenes",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["projectId", "orderIndex"])]
)
data class SceneEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val projectId: Long,
    val orderIndex: Int, // 1-indexed (1, 2, 3...)
    val sceneTitle: String, // e.g. "Escena 1"
    val promptContent: String, // original user scene text
    val fullCombinedPrompt: String, // visual style + scene prompt
    val status: String = "PENDING", // PENDING, PROCESSING, COMPLETED, FAILED, PAUSED
    val localFilePath: String? = null,
    val fileUri: String? = null,
    val errorMessage: String? = null,
    val progressPercent: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
