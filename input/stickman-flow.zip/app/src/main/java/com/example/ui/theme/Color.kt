package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Studio Palette - Stickman Flow
val DarkBackground = Color(0xFF0F1218)
val DarkSurface = Color(0xFF161B24)
val DarkSurfaceVariant = Color(0xFF202735)
val DarkSurfaceContainer = Color(0xFF283142)

val CyanPrimary = Color(0xFF38BDF8)
val CyanPrimaryContainer = Color(0xFF0A3A54)
val CyanOnPrimary = Color(0xFF001E2E)

val AmberSecondary = Color(0xFFFBBF24)
val AmberSecondaryContainer = Color(0xFF4C3800)
val AmberOnSecondary = Color(0xFF291800)

val VioletTertiary = Color(0xFFA78BFA)
val VioletTertiaryContainer = Color(0xFF38236B)

val SuccessGreen = Color(0xFF34D399)
val ErrorRed = Color(0xFFF87171)

// Light Theme Fallback
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFFD97706)
