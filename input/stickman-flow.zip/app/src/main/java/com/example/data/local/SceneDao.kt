package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SceneDao {
    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getScenesForProject(projectId: Long): Flow<List<SceneEntity>>

    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY orderIndex ASC")
    suspend fun getScenesListForProject(projectId: Long): List<SceneEntity>

    @Query("SELECT * FROM scenes WHERE id = :id LIMIT 1")
    suspend fun getSceneById(id: Long): SceneEntity?

    @Query("SELECT * FROM scenes WHERE projectId = :projectId AND status = 'COMPLETED' ORDER BY orderIndex ASC")
    fun getCompletedScenes(projectId: Long): Flow<List<SceneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScene(scene: SceneEntity): Long

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Update
    suspend fun updateScenes(scenes: List<SceneEntity>)

    @Delete
    suspend fun deleteScene(scene: SceneEntity)

    @Query("DELETE FROM scenes WHERE id = :id")
    suspend fun deleteSceneById(id: Long)

    @Query("DELETE FROM scenes WHERE projectId = :projectId")
    suspend fun deleteAllScenesForProject(projectId: Long)

    @Query("UPDATE scenes SET status = 'PENDING', progressPercent = 0, errorMessage = null WHERE projectId = :projectId AND status = 'FAILED'")
    suspend fun resetFailedScenes(projectId: Long)

    @Query("UPDATE scenes SET status = :status, progressPercent = :progress, errorMessage = :error WHERE id = :id")
    suspend fun updateSceneProgress(id: Long, status: String, progress: Int, error: String? = null)
}
