package com.example.domain

import com.example.data.local.ProjectEntity
import com.example.data.local.SceneEntity
import com.example.data.repository.GenerationRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class QueueState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val currentSceneId: Long? = null,
    val currentSceneTitle: String = "",
    val currentProgress: Int = 0,
    val currentStatusMessage: String = "Listo",
    val completedInSession: Int = 0,
    val failedInSession: Int = 0
)

class GenerationQueueManager(
    private val repository: GenerationRepository
) {
    private val _queueState = MutableStateFlow(QueueState())
    val queueState: StateFlow<QueueState> = _queueState.asStateFlow()

    private var activeJob: Job? = null

    fun startQueue(
        project: ProjectEntity,
        scenes: List<SceneEntity>,
        scope: CoroutineScope,
        forceOfflineSketch: Boolean = false
    ) {
        if (_queueState.value.isRunning && !_queueState.value.isPaused) return

        _queueState.update {
            it.copy(
                isRunning = true,
                isPaused = false,
                currentStatusMessage = "Iniciando procesamiento de cola..."
            )
        }

        activeJob = scope.launch {
            try {
                // Find all scenes that are not COMPLETED, sorted by orderIndex
                val queueToProcess = scenes.filter { it.status != "COMPLETED" }.sortedBy { it.orderIndex }

                for (scene in queueToProcess) {
                    if (_queueState.value.isPaused) {
                        _queueState.update { it.copy(currentStatusMessage = "Cola pausada") }
                        break
                    }

                    _queueState.update {
                        it.copy(
                            currentSceneId = scene.id,
                            currentSceneTitle = "${scene.sceneTitle} (Orden #${scene.orderIndex})",
                            currentProgress = 10,
                            currentStatusMessage = "Procesando ${scene.sceneTitle}..."
                        )
                    }

                    repository.updateSceneProgress(scene.id, "PROCESSING", 10)

                    // Check if user is using API generation or Flow assistant or sketch
                    val apiKey = repository.getApiKey()
                    if (apiKey.isNotBlank() && !forceOfflineSketch) {
                        // Real Google AI / Imagen 3 API generation
                        val result = repository.generateSceneContent(project, scene) { percent, msg ->
                            _queueState.update {
                                it.copy(
                                    currentProgress = percent,
                                    currentStatusMessage = msg
                                )
                            }
                        }

                        if (result.isSuccess) {
                            _queueState.update {
                                it.copy(
                                    completedInSession = it.completedInSession + 1,
                                    currentProgress = 100,
                                    currentStatusMessage = "${scene.sceneTitle} completada exitosamente"
                                )
                            }
                        } else {
                            val err = result.exceptionOrNull()?.message ?: "Error desconocido"
                            _queueState.update {
                                it.copy(
                                    failedInSession = it.failedInSession + 1,
                                    currentStatusMessage = "Error en ${scene.sceneTitle}: $err"
                                )
                            }
                        }
                    } else {
                        // If no API key configured, generate high-fidelity local stickman sketch
                        // so user has a fully working on-device storyboard while configuring their key!
                        _queueState.update {
                            it.copy(
                                currentProgress = 50,
                                currentStatusMessage = "Generando storyboard stickman local para ${scene.sceneTitle}..."
                            )
                        }
                        delay(600) // Visual pacing
                        repository.generateLocalStoryboardSketch(project, scene)
                        _queueState.update {
                            it.copy(
                                completedInSession = it.completedInSession + 1,
                                currentProgress = 100,
                                currentStatusMessage = "${scene.sceneTitle} renderizada en storyboard local"
                            )
                        }
                    }

                    delay(400) // Brief pause between scenes for smooth UI updates
                }

                _queueState.update {
                    it.copy(
                        isRunning = false,
                        isPaused = false,
                        currentSceneId = null,
                        currentProgress = 100,
                        currentStatusMessage = "Cola de procesamiento finalizada"
                    )
                }
            } catch (e: CancellationException) {
                _queueState.update {
                    it.copy(
                        isRunning = false,
                        isPaused = false,
                        currentSceneId = null,
                        currentStatusMessage = "Cola cancelada por el usuario"
                    )
                }
            } catch (e: Exception) {
                _queueState.update {
                    it.copy(
                        isRunning = false,
                        isPaused = false,
                        currentStatusMessage = "Error en la cola: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun pauseQueue() {
        _queueState.update {
            it.copy(
                isPaused = true,
                currentStatusMessage = "Cola pausada. Las tareas completadas están a salvo."
            )
        }
    }

    fun resumeQueue(
        project: ProjectEntity,
        scenes: List<SceneEntity>,
        scope: CoroutineScope,
        forceOfflineSketch: Boolean = false
    ) {
        _queueState.update { it.copy(isPaused = false) }
        startQueue(project, scenes, scope, forceOfflineSketch)
    }

    fun cancelQueue() {
        activeJob?.cancel()
        _queueState.update {
            it.copy(
                isRunning = false,
                isPaused = false,
                currentSceneId = null,
                currentProgress = 0,
                currentStatusMessage = "Cola cancelada"
            )
        }
    }

    fun retryFailed(
        project: ProjectEntity,
        scenes: List<SceneEntity>,
        scope: CoroutineScope,
        forceOfflineSketch: Boolean = false
    ) {
        scope.launch {
            repository.resetFailedScenes(project.id)
            val updatedScenes = repository.getScenesList(project.id)
            startQueue(project, updatedScenes, scope, forceOfflineSketch)
        }
    }

    fun processSingleScene(
        project: ProjectEntity,
        scene: SceneEntity,
        scope: CoroutineScope,
        forceOfflineSketch: Boolean = false
    ) {
        scope.launch {
            repository.updateSceneProgress(scene.id, "PROCESSING", 10)
            val apiKey = repository.getApiKey()
            if (apiKey.isNotBlank() && !forceOfflineSketch) {
                repository.generateSceneContent(project, scene) { _, _ -> }
            } else {
                repository.generateLocalStoryboardSketch(project, scene)
            }
        }
    }
}
