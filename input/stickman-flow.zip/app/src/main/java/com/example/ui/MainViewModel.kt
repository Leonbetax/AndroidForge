package com.example.ui

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectEntity
import com.example.data.local.SceneEntity
import com.example.data.local.StickmanFlowDatabase
import com.example.data.repository.GenerationRepository
import com.example.domain.BatchPromptParser
import com.example.domain.FileStorageManager
import com.example.domain.GenerationQueueManager
import com.example.domain.QueueState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = StickmanFlowDatabase.getDatabase(application)
    private val fileStorageManager = FileStorageManager(application)
    val repository = GenerationRepository(
        context = application,
        projectDao = database.projectDao(),
        sceneDao = database.sceneDao(),
        fileStorageManager = fileStorageManager
    )
    val queueManager = GenerationQueueManager(repository)

    // Current screen navigation index (0: Inicio, 1: Editor, 2: Estilo, 3: Cola, 4: Galería, 5: Ajustes)
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // All projects
    val allProjects: StateFlow<List<ProjectEntity>> = repository.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently selected active project
    private val _activeProject = MutableStateFlow<ProjectEntity?>(null)
    val activeProject: StateFlow<ProjectEntity?> = _activeProject.asStateFlow()

    // Scenes for the currently active project
    val activeScenes: StateFlow<List<SceneEntity>> = _activeProject.flatMapLatest { project ->
        if (project != null) {
            repository.getScenesForProject(project.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Queue state from manager
    val queueState: StateFlow<QueueState> = queueManager.queueState

    // Batch editor raw text
    private val _batchInputText = MutableStateFlow("")
    val batchInputText: StateFlow<String> = _batchInputText.asStateFlow()

    // Visual style field
    private val _visualStyleText = MutableStateFlow(BatchPromptParser.DEFAULT_STICKMAN_STYLE)
    val visualStyleText: StateFlow<String> = _visualStyleText.asStateFlow()

    // Reference Image URI
    private val _referenceImageUri = MutableStateFlow<String?>(null)
    val referenceImageUri: StateFlow<String?> = _referenceImageUri.asStateFlow()

    // Generation Mode ("IMAGES" vs "VIDEOS")
    private val _generationMode = MutableStateFlow("IMAGES")
    val generationMode: StateFlow<String> = _generationMode.asStateFlow()

    // Engine Mode ("IMAGEN_API" vs "FLOW_ASSISTANT")
    private val _engineMode = MutableStateFlow("IMAGEN_API")
    val engineMode: StateFlow<String> = _engineMode.asStateFlow()

    // API Key
    private val _apiKeyText = MutableStateFlow(repository.getApiKey())
    val apiKeyText: StateFlow<String> = _apiKeyText.asStateFlow()

    // UI Dialogs
    private val _sceneToEdit = MutableStateFlow<SceneEntity?>(null)
    val sceneToEdit: StateFlow<SceneEntity?> = _sceneToEdit.asStateFlow()

    private val _showNewProjectDialog = MutableStateFlow(false)
    val showNewProjectDialog: StateFlow<Boolean> = _showNewProjectDialog.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _selectedGalleryScene = MutableStateFlow<SceneEntity?>(null)
    val selectedGalleryScene: StateFlow<SceneEntity?> = _selectedGalleryScene.asStateFlow()

    init {
        // Automatically load latest project or bootstrap a starter project
        viewModelScope.launch {
            repository.getLatestProject().collect { latest ->
                if (latest != null) {
                    if (_activeProject.value == null) {
                        selectProject(latest)
                    }
                } else {
                    // Create default first project
                    createNewProject(
                        projectName = "Episodio 1: Stickman en el Jardín",
                        initialBatchText = BatchPromptParser.SAMPLE_BATCH_SCRIPT
                    )
                }
            }
        }
    }

    fun setTab(index: Int) {
        _currentTab.value = index
    }

    fun selectProject(project: ProjectEntity) {
        _activeProject.value = project
        _visualStyleText.value = project.visualStyle
        _referenceImageUri.value = project.referenceImageUri
        _generationMode.value = project.generationMode
        _engineMode.value = project.engineMode
        _batchInputText.value = project.rawBatchText
    }

    fun createNewProject(
        projectName: String,
        initialBatchText: String = "",
        initialStyle: String = BatchPromptParser.DEFAULT_STICKMAN_STYLE
    ) {
        viewModelScope.launch {
            val newProject = ProjectEntity(
                name = projectName.ifBlank { "Nuevo Proyecto Stickman" },
                visualStyle = initialStyle,
                rawBatchText = initialBatchText,
                generationMode = _generationMode.value,
                engineMode = _engineMode.value
            )
            val newId = repository.saveProject(newProject)
            val created = newProject.copy(id = newId)
            _activeProject.value = created
            _visualStyleText.value = created.visualStyle
            _batchInputText.value = created.rawBatchText
            _showNewProjectDialog.value = false

            // Parse initial scenes if provided
            if (initialBatchText.isNotBlank()) {
                parseAndSaveBatchText(initialBatchText, created)
            }
        }
    }

    fun updateBatchInputText(text: String) {
        _batchInputText.value = text
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(project.copy(rawBatchText = text, updatedAt = System.currentTimeMillis()))
        }
    }

    fun parseAndSaveBatchText(text: String, targetProject: ProjectEntity? = _activeProject.value) {
        val project = targetProject ?: return
        viewModelScope.launch {
            val parsedList = BatchPromptParser.parseBatchText(text)
            val style = _visualStyleText.value
            val hasRef = _referenceImageUri.value != null

            val entities = parsedList.map { parsed ->
                SceneEntity(
                    projectId = project.id,
                    orderIndex = parsed.orderIndex,
                    sceneTitle = parsed.title,
                    promptContent = parsed.prompt,
                    fullCombinedPrompt = BatchPromptParser.buildCombinedPrompt(
                        scenePrompt = parsed.prompt,
                        visualStyle = style,
                        hasReferenceImage = hasRef,
                        isGoogleFlowMode = project.engineMode == "FLOW_ASSISTANT"
                    ),
                    status = "PENDING",
                    progressPercent = 0
                )
            }

            repository.deleteAllScenes(project.id)
            repository.insertScenes(entities)
            repository.updateProject(project.copy(rawBatchText = text, updatedAt = System.currentTimeMillis()))
            Toast.makeText(
                getApplication(),
                "¡${entities.size} escenas guardadas en el proyecto!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun updateVisualStyle(newStyle: String) {
        _visualStyleText.value = newStyle
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(project.copy(visualStyle = newStyle, updatedAt = System.currentTimeMillis()))
            // Update combined prompts in existing scenes
            val currentScenes = repository.getScenesList(project.id)
            val hasRef = _referenceImageUri.value != null
            val updated = currentScenes.map { scene ->
                scene.copy(
                    fullCombinedPrompt = BatchPromptParser.buildCombinedPrompt(
                        scenePrompt = scene.promptContent,
                        visualStyle = newStyle,
                        hasReferenceImage = hasRef,
                        isGoogleFlowMode = project.engineMode == "FLOW_ASSISTANT"
                    )
                )
            }
            repository.updateScenes(updated)
        }
    }

    fun setReferenceImageUri(uriString: String?) {
        _referenceImageUri.value = uriString
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(project.copy(referenceImageUri = uriString, updatedAt = System.currentTimeMillis()))
            // Update scenes prompt reflection
            updateVisualStyle(_visualStyleText.value)
        }
    }

    fun setGenerationMode(mode: String) {
        _generationMode.value = mode
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(project.copy(generationMode = mode, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setEngineMode(engine: String) {
        _engineMode.value = engine
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.updateProject(project.copy(engineMode = engine, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setApiKey(key: String) {
        _apiKeyText.value = key
        repository.saveApiKey(key)
        Toast.makeText(getApplication(), "Clave de Google AI guardada", Toast.LENGTH_SHORT).show()
    }

    fun addScene(afterOrder: Int? = null) {
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            val currentList = repository.getScenesList(project.id).toMutableList()
            val newOrder = (afterOrder ?: currentList.size) + 1
            val newScene = SceneEntity(
                projectId = project.id,
                orderIndex = newOrder,
                sceneTitle = "Escena $newOrder",
                promptContent = "Nueva acción para el stickman...",
                fullCombinedPrompt = BatchPromptParser.buildCombinedPrompt(
                    scenePrompt = "Nueva acción para el stickman...",
                    visualStyle = _visualStyleText.value,
                    hasReferenceImage = _referenceImageUri.value != null,
                    isGoogleFlowMode = project.engineMode == "FLOW_ASSISTANT"
                )
            )
            // Shift subsequent scenes if inserted in middle
            if (afterOrder != null && afterOrder < currentList.size) {
                currentList.add(afterOrder, newScene)
                val renumbered = currentList.mapIndexed { idx, sc ->
                    val num = idx + 1
                    sc.copy(orderIndex = num, sceneTitle = "Escena $num")
                }
                repository.deleteAllScenes(project.id)
                repository.insertScenes(renumbered)
            } else {
                repository.insertScene(newScene)
            }
        }
    }

    fun moveScene(scene: SceneEntity, moveUp: Boolean) {
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            val list = repository.getScenesList(project.id).sortedBy { it.orderIndex }.toMutableList()
            val currentIndex = list.indexOfFirst { it.id == scene.id }
            if (currentIndex == -1) return@launch

            val targetIndex = if (moveUp) currentIndex - 1 else currentIndex + 1
            if (targetIndex in list.indices) {
                val item = list.removeAt(currentIndex)
                list.add(targetIndex, item)
                // Renumber orderIndex
                val updated = list.mapIndexed { idx, sc ->
                    val num = idx + 1
                    sc.copy(orderIndex = num, sceneTitle = "Escena $num")
                }
                repository.updateScenes(updated)
            }
        }
    }

    fun deleteScene(scene: SceneEntity) {
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            repository.deleteScene(scene)
            // Renumber remaining scenes
            val remaining = repository.getScenesList(project.id).sortedBy { it.orderIndex }
            val renumbered = remaining.mapIndexed { idx, sc ->
                val num = idx + 1
                sc.copy(orderIndex = num, sceneTitle = "Escena $num")
            }
            repository.updateScenes(renumbered)
        }
    }

    fun updateSingleScenePrompt(sceneId: Long, newPrompt: String) {
        val project = _activeProject.value ?: return
        viewModelScope.launch {
            val current = repository.getScenesList(project.id).find { it.id == sceneId } ?: return@launch
            val updated = current.copy(
                promptContent = newPrompt,
                fullCombinedPrompt = BatchPromptParser.buildCombinedPrompt(
                    scenePrompt = newPrompt,
                    visualStyle = _visualStyleText.value,
                    hasReferenceImage = _referenceImageUri.value != null,
                    isGoogleFlowMode = project.engineMode == "FLOW_ASSISTANT"
                ),
                status = "PENDING",
                errorMessage = null,
                progressPercent = 0
            )
            repository.updateScene(updated)
            _sceneToEdit.value = null
        }
    }

    fun startOrResumeQueue(forceOfflineSketch: Boolean = false) {
        val project = _activeProject.value ?: return
        val scenes = activeScenes.value
        if (scenes.isEmpty()) {
            Toast.makeText(getApplication(), "No hay escenas en el proyecto para procesar", Toast.LENGTH_SHORT).show()
            return
        }
        _currentTab.value = 3 // Switch to Queue tab
        queueManager.startQueue(project, scenes, viewModelScope, forceOfflineSketch)
    }

    fun pauseQueue() {
        queueManager.pauseQueue()
    }

    fun resumeQueue(forceOfflineSketch: Boolean = false) {
        val project = _activeProject.value ?: return
        queueManager.resumeQueue(project, activeScenes.value, viewModelScope, forceOfflineSketch)
    }

    fun cancelQueue() {
        queueManager.cancelQueue()
    }

    fun retryFailedScenes(forceOfflineSketch: Boolean = false) {
        val project = _activeProject.value ?: return
        queueManager.retryFailed(project, activeScenes.value, viewModelScope, forceOfflineSketch)
    }

    fun reprocessSingleScene(scene: SceneEntity, forceOfflineSketch: Boolean = false) {
        val project = _activeProject.value ?: return
        queueManager.processSingleScene(project, scene, viewModelScope, forceOfflineSketch)
    }

    fun copyPromptToClipboard(prompt: String) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = android.content.ClipData.newPlainText("Stickman Prompt", prompt)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "Prompt copiado al portapapeles", Toast.LENGTH_SHORT).show()
    }

    fun openGoogleFlowWeb() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://flow.google")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://labs.google/flow")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(fallbackIntent)
            } catch (e: Exception) {
                Toast.makeText(getApplication(), "No se pudo abrir el navegador: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareCompletedScenes() {
        val project = _activeProject.value ?: return
        val completed = activeScenes.value.filter { it.status == "COMPLETED" && !it.localFilePath.isNullOrBlank() }
        if (completed.isEmpty()) {
            Toast.makeText(getApplication(), "No hay escenas generadas para compartir", Toast.LENGTH_SHORT).show()
            return
        }
        val files = completed.mapNotNull { it.localFilePath?.let { path -> File(path) } }.filter { it.exists() }
        val shareIntent = repository.createShareIntent(files, project.name).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(shareIntent, "Compartir escenas de ${project.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(chooser)
    }

    fun shareSingleScene(scene: SceneEntity) {
        val path = scene.localFilePath ?: return
        val file = File(path)
        if (!file.exists()) return
        val shareIntent = repository.createShareIntent(listOf(file), scene.sceneTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(shareIntent, "Compartir ${scene.sceneTitle}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(chooser)
    }

    fun setEditingScene(scene: SceneEntity?) {
        _sceneToEdit.value = scene
    }

    fun setShowNewProjectDialog(show: Boolean) {
        _showNewProjectDialog.value = show
    }

    fun setShowSettingsDialog(show: Boolean) {
        _showSettingsDialog.value = show
    }

    fun setSelectedGalleryScene(scene: SceneEntity?) {
        _selectedGalleryScene.value = scene
    }
}
